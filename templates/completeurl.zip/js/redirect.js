var clickToggle = false;
$(document).ready(
	function(){
		//redirects back to the index page after 5 seconds
		setTimeout(function(){ 
			window.location.replace("index.html");
		}, 5000);
	}
);
